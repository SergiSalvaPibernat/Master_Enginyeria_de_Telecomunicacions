package main;

import util.Message;
import util.Subscription_check;
import util.Topic;
import subscriber.SubscriberImpl;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import java.util.HashMap;
import java.util.Map;
import publisher.Publisher;
import subscriber.Subscriber;
import topicmanager.TopicManager;

public class SwingClient {

    TopicManager topicManager;
    public Map<Topic, Subscriber> my_subscriptions;
    Publisher publisher;
    Topic publisherTopic;

    JFrame frame;
    JTextArea topic_list_TextArea;
    public JTextArea messages_TextArea;
    public JTextArea my_subscriptions_TextArea;
    JTextArea publisher_TextArea;
    JTextField argument_TextField;

    public SwingClient(TopicManager topicManager) {
        this.topicManager = topicManager;
        my_subscriptions = new HashMap<Topic, Subscriber>();
        publisher = null;
        publisherTopic = null;
    }

    public void createAndShowGUI() {

        frame = new JFrame("Publisher/Subscriber demo");
        frame.setSize(300, 300);
        frame.addWindowListener(new CloseWindowHandler());

        topic_list_TextArea = new JTextArea(5, 10);
        messages_TextArea = new JTextArea(10, 20);
        my_subscriptions_TextArea = new JTextArea(5, 10);
        publisher_TextArea = new JTextArea(1, 10);
        argument_TextField = new JTextField(20);

        JButton show_topics_button = new JButton("show Topics");
        JButton new_publisher_button = new JButton("new Publisher");
        JButton new_subscriber_button = new JButton("new Subscriber");
        JButton to_unsubscribe_button = new JButton("to unsubscribe");
        JButton to_post_an_event_button = new JButton("post an event");
        JButton to_close_the_app = new JButton("close app.");

        show_topics_button.addActionListener(new showTopicsHandler());
        new_publisher_button.addActionListener(new newPublisherHandler());
        new_subscriber_button.addActionListener(new newSubscriberHandler());
        to_unsubscribe_button.addActionListener(new UnsubscribeHandler());
        to_post_an_event_button.addActionListener(new postEventHandler());
        to_close_the_app.addActionListener(new CloseAppHandler());

        JPanel buttonsPannel = new JPanel(new FlowLayout());
        buttonsPannel.add(show_topics_button);
        buttonsPannel.add(new_publisher_button);
        buttonsPannel.add(new_subscriber_button);
        buttonsPannel.add(to_unsubscribe_button);
        buttonsPannel.add(to_post_an_event_button);
        buttonsPannel.add(to_close_the_app);

        JPanel argumentP = new JPanel(new FlowLayout());
        argumentP.add(new JLabel("Write content to set a new_publisher / new_subscriber / unsubscribe / post_event:"));
        argumentP.add(argument_TextField);

        JPanel topicsP = new JPanel();
        topicsP.setLayout(new BoxLayout(topicsP, BoxLayout.PAGE_AXIS));
        topicsP.add(new JLabel("Topics:"));
        topicsP.add(topic_list_TextArea);
        topicsP.add(new JScrollPane(topic_list_TextArea));
        topicsP.add(new JLabel("My Subscriptions:"));
        topicsP.add(my_subscriptions_TextArea);
        topicsP.add(new JScrollPane(my_subscriptions_TextArea));
        topicsP.add(new JLabel("I'm Publisher of topic:"));
        topicsP.add(publisher_TextArea);
        topicsP.add(new JScrollPane(publisher_TextArea));

        JPanel messagesPanel = new JPanel();
        messagesPanel.setLayout(new BoxLayout(messagesPanel, BoxLayout.PAGE_AXIS));
        messagesPanel.add(new JLabel("Messages:"));
        messagesPanel.add(messages_TextArea);
        messagesPanel.add(new JScrollPane(messages_TextArea));

        Container mainPanel = frame.getContentPane();
        mainPanel.add(buttonsPannel, BorderLayout.PAGE_START);
        mainPanel.add(messagesPanel, BorderLayout.CENTER);
        mainPanel.add(argumentP, BorderLayout.PAGE_END);
        mainPanel.add(topicsP, BorderLayout.LINE_START);

        frame.pack();
        frame.setVisible(true);
    }

    class showTopicsHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            ArrayList<Topic> topics = new ArrayList<Topic>(SwingClient.this.topicManager.topics());

            if (!topics.isEmpty()) {
                topic_list_TextArea.setText("");
                for (Topic topic : topics) {
                    topic_list_TextArea.append(topic.name + "\n");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "No topics available.");
            }

        }
    }

    class newPublisherHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            String topicName = argument_TextField.getText().trim();

            if (!topicName.isEmpty()) {
                Topic newTopic = new Topic(topicName);
                if (!topicManager.topics().contains(newTopic)) {
                    publisher = topicManager.addPublisherToTopic(newTopic);
                    publisherTopic = newTopic;
                    publisher_TextArea.setText(topicName);
                    topic_list_TextArea.setText("");
                    for (Topic topic : topicManager.topics()) {
                        topic_list_TextArea.append(topic.name + "\n");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "This topic already exists.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a valid topic name.");
            }

        }
    }

    class newSubscriberHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            String topicName = argument_TextField.getText().trim();

            if (!topicName.isEmpty()) {
                Topic topicToSubscribe = new Topic(topicName);
                if (topicManager.topics().contains(topicToSubscribe)) {
                    Subscriber subscriber = new SubscriberImpl(SwingClient.this);
                    Subscription_check subscriptionCheck = topicManager.subscribe(topicToSubscribe, subscriber);
                    if (subscriptionCheck.result == Subscription_check.Result.OKAY) {
                        my_subscriptions.put(topicToSubscribe, subscriber);
                        my_subscriptions_TextArea.setText("");
                        for (Topic topic : my_subscriptions.keySet()) {
                            my_subscriptions_TextArea.append(topic.name + "\n");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to subscribe. " + subscriptionCheck.result);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid topic name");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a valid topic name.");
            }
        }
    }

    class UnsubscribeHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            String topicName = argument_TextField.getText().trim();

            if (!topicName.isEmpty()) {
                Topic topicToUnsubscribe = new Topic(topicName);

                if (my_subscriptions.containsKey(topicToUnsubscribe)) {
                    Subscriber subscriber = my_subscriptions.get(topicToUnsubscribe);
                    Subscription_check unsubscriptionCheck = topicManager.unsubscribe(topicToUnsubscribe, subscriber);

                    if (unsubscriptionCheck.result == Subscription_check.Result.OKAY) {
                        my_subscriptions.remove(topicToUnsubscribe);
                        my_subscriptions_TextArea.setText("");
                        for (Topic topic : my_subscriptions.keySet()) {
                            my_subscriptions_TextArea.append(topic.name + "\n");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to unsubscribe. " + unsubscriptionCheck.result);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "You are not subscribed to this topic.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a valid topic name.");
            }
        }
    }

    class postEventHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            String content = argument_TextField.getText().trim();
            if (!content.isEmpty() && publisher != null) {
                Message message = new Message(publisherTopic, content);
                publisher.publish(message);
                messages_TextArea.append(publisherTopic.name + ": " + content + "\n");
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter valid content and ensure you are a publisher.");
            }
        }
    }

    class CloseAppHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            for (int i = 0; i < my_subscriptions.size(); i++) {
                topicManager.unsubscribe(publisherTopic, my_subscriptions.get(i));
            }
            topicManager.removePublisherFromTopic(publisherTopic);
            my_subscriptions.clear();

            System.out.println("one user closed");
            System.exit(0);
        }
    }

    class CloseWindowHandler implements WindowListener {

        public void windowDeactivated(WindowEvent e) {
        }

        public void windowActivated(WindowEvent e) {
        }

        public void windowIconified(WindowEvent e) {
        }

        public void windowDeiconified(WindowEvent e) {
        }

        public void windowClosed(WindowEvent e) {
        }

        public void windowOpened(WindowEvent e) {
        }

        public void windowClosing(WindowEvent e) {

            for (int i = 0; i < my_subscriptions.size(); i++) {
                topicManager.unsubscribe(publisherTopic, my_subscriptions.get(i));
            }
            topicManager.removePublisherFromTopic(publisherTopic);
            my_subscriptions.clear();

            System.out.println("one user closed");
            System.exit(0);

        }
    }
}
